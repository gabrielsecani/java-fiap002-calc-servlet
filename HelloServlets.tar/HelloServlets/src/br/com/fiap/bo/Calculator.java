package br.com.fiap.bo;

import java.text.NumberFormat;

public class Calculator {
	private String operator;
	private Double number1;
	private Double number2;
	
	public Calculator(String operator, Double number1, Double number2) {
		super();
		this.operator = operator;
		this.number1 = number1;
		this.number2 = number2;
	}
	
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public Double getNumber1() {
		return number1;
	}
	public void setNumber1(Double number1) {
		this.number1 = number1;
	}
	public Double getNumber2() {
		return number2;
	}
	public void setNumber2(Double number2) {
		this.number2 = number2;
	}	

	private Double sum() {
		return number1 + number2;
	}

	private Double subtract() {
		return number1 - number2;
	}

	private Double multiply() {
		return number1 / number2;
	}
	
	private Double divide() {
		if(number1 == 0) {
			throw new ArithmeticException();
		}
		return number1 / number2;
	}
	
	public String calculate() {
		Double resultado = null;
		switch(operator) {
			case "+":
				resultado = sum();
				break;
			case "-":
				resultado = subtract();
				break;
			case "*":
				resultado = multiply();
				break;
			case "/":
				resultado = divide();
				break;
		}
		
		NumberFormat formatter = NumberFormat.getInstance();
		formatter.setMaximumIntegerDigits(2);
		
		return formatter.format(resultado);
	}

}
