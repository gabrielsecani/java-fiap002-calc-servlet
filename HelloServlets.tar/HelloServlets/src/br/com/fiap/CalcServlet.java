package br.com.fiap;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.javafx.css.CalculatedValue;

import br.com.fiap.bo.Calculator;

/**
 * Servlet implementation class CalcServlet
 */
@WebServlet(description = "Bora calcular negada!", urlPatterns = { "/calcular" })
public class CalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalcServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		calculate(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		calculate(request, response);
	}
	
	protected void calculate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Double number1 = Double.parseDouble(request.getParameter("txtNumero1"));
		Double number2 = Double.parseDouble(request.getParameter("txtNumero2"));
		String operator = request.getParameter("cboOperacao");
		String resul = null;
		try {
			Calculator calc = new Calculator(operator, number1, number2);
			resul = calc.calculate();
		} catch(ArithmeticException e) {
			resul = "Voce nao dividir";
		} finally {
			response.getWriter().println(resul);
		}
		
		
	}

}
